"""
Utilidades para un proyecto Django.
"""