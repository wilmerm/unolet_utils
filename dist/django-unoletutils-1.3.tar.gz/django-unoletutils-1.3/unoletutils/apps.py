from django.apps import AppConfig


class UnoletutilsConfig(AppConfig):
    name = 'unoletutils'
